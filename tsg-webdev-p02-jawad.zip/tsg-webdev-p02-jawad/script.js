const header=document.querySelector('.header');
const menu=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav-links');
const navLinks=document.querySelectorAll('.nav-links a');

window.addEventListener('scroll',()=>header.classList.toggle('scrolled',scrollY>30));
menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');document.body.classList.toggle('menu-open',open);menu.setAttribute('aria-expanded',open)});
navLinks.forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');document.body.classList.remove('menu-open');menu.setAttribute('aria-expanded','false')}));

const sections=[...document.querySelectorAll('main section[id]')];
const links=[...document.querySelectorAll('.nav-links a[href^="#"]')];
const spy=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){links.forEach(l=>l.classList.toggle('active',l.getAttribute('href')==='#'+e.target.id))}}),{rootMargin:'-35% 0px -55% 0px'});
sections.forEach(s=>spy.observe(s));

const reveal=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('show')}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(x=>reveal.observe(x));

// FAQ accordion
for(const item of document.querySelectorAll('.faq')){
  item.querySelector('button').addEventListener('click',()=>{
    const wasOpen=item.classList.contains('open');
    document.querySelectorAll('.faq').forEach(x=>{x.classList.remove('open');x.querySelector('button').setAttribute('aria-expanded','false')});
    if(!wasOpen){item.classList.add('open');item.querySelector('button').setAttribute('aria-expanded','true')}
  });
}

// Testimonials
const track=document.querySelector('.track'), slides=[...document.querySelectorAll('.testimonial')], dots=document.querySelector('.dots');
let current=0;
slides.forEach((_,i)=>{const d=document.createElement('span');d.className='dot'+(i===0?' active':'');d.addEventListener('click',()=>go(i));dots.appendChild(d)});
function go(i){current=(i+slides.length)%slides.length;track.style.transform=`translateX(-${current*100}%)`;[...dots.children].forEach((d,n)=>d.classList.toggle('active',n===current))}
document.querySelector('#prev').onclick=()=>go(current-1);document.querySelector('#next').onclick=()=>go(current+1);
let auto=setInterval(()=>go(current+1),6000);document.querySelector('.testimonial-wrap').addEventListener('mouseenter',()=>clearInterval(auto));

// Demo contact form — replace this block with your backend/API later.
document.querySelector('#contactForm').addEventListener('submit',e=>{e.preventDefault();const form=e.currentTarget;if(!form.checkValidity()){form.reportValidity();return}form.querySelector('.status').textContent='Thanks! Your trial request has been received. We will contact you shortly.';form.reset()});
